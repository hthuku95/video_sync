"""
Async Job Queue — Phase 5

Allows callers to submit long-running Blender/Manim jobs asynchronously and
poll for results.  The queue runs entirely in-process using asyncio — no Redis
or external broker required.

Usage (from server.py):
    from tools.job_queue import queue, JobStatus

    job_id = await queue.submit("blender_generate_scene", {"prompt": "...", ...})
    # ... later ...
    status = queue.get(job_id)   # returns JobStatus

REST endpoints (wired in server.py):
    POST /api/jobs           — submit a job, returns {"job_id": str}
    GET  /api/jobs/{job_id}  — poll job status
"""

from __future__ import annotations

import asyncio
import inspect
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Coroutine

from tools.progress_store import record_job_progress


class State(str, Enum):
    PENDING   = "pending"
    RUNNING   = "running"
    COMPLETED = "completed"
    FAILED    = "failed"


@dataclass
class JobStatus:
    job_id:    str
    tool:      str
    workflow_thread_id: str = ""
    state:     State          = State.PENDING
    result:    dict | None    = None
    error:     str            = ""
    created_at: str           = field(default_factory=lambda: _now())
    started_at: str           = ""
    finished_at: str          = ""

    def to_dict(self) -> dict:
        return {
            "job_id":      self.job_id,
            "tool":        self.tool,
            "workflow_thread_id": self.workflow_thread_id,
            "state":       self.state.value,
            "result":      self.result,
            "error":       self.error,
            "created_at":  self.created_at,
            "started_at":  self.started_at,
            "finished_at": self.finished_at,
        }


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Queue
# ---------------------------------------------------------------------------

class JobQueue:
    """
    In-process async job queue.

    Workers run concurrently up to `max_workers` at a time (default 2 —
    Render Standard has 1 vCPU but Blender renders are I/O-heavy).
    """

    def __init__(self, max_workers: int = 2):
        self._jobs: dict[str, JobStatus] = {}
        self._pending: asyncio.Queue[str] = asyncio.Queue()
        self._max_workers = max_workers
        self._tool_registry: dict[str, Callable[..., Coroutine[Any, Any, dict]]] = {}
        self._started = False

    def register(self, tool_name: str, fn: Callable[..., Coroutine[Any, Any, dict]]) -> None:
        """Register a coroutine function as the handler for a tool name."""
        self._tool_registry[tool_name] = fn

    @staticmethod
    def _filter_handler_args(
        handler: Callable[..., Coroutine[Any, Any, dict]],
        args: dict,
    ) -> dict:
        """
        Pass workflow metadata only to handlers that explicitly accept it.

        The queue owns orchestration fields such as `workflow_thread_id`, but
        several older render handlers still have narrow signatures. Filtering
        here keeps durable progress tracking without turning queue metadata
        into unexpected keyword argument failures.
        """
        try:
            signature = inspect.signature(handler)
        except (TypeError, ValueError):
            return dict(args)

        if any(
            parameter.kind == inspect.Parameter.VAR_KEYWORD
            for parameter in signature.parameters.values()
        ):
            return dict(args)

        allowed = set(signature.parameters)
        return {key: value for key, value in args.items() if key in allowed}

    async def submit(self, tool_name: str, args: dict) -> str:
        """Submit a job and return its job_id.  Starts worker loop on first call."""
        if not self._started:
            await self._start_workers()

        job_id = str(uuid.uuid4())
        normalized_args = dict(args or {})
        workflow_thread_id = str(normalized_args.get("workflow_thread_id") or job_id)
        normalized_args["workflow_thread_id"] = workflow_thread_id
        status = JobStatus(job_id=job_id, tool=tool_name, workflow_thread_id=workflow_thread_id)
        status.result = normalized_args  # store args temporarily (overwritten on completion)
        self._jobs[job_id] = status

        # Store args alongside job so worker can retrieve them
        self._jobs[job_id]._args = normalized_args  # type: ignore[attr-defined]
        await record_job_progress(
            job_id=job_id,
            workflow_thread_id=workflow_thread_id,
            tool=tool_name,
            state=State.PENDING.value,
            stage="queued",
            message=f"Queued {tool_name} job",
            details={
                "arg_keys": sorted(normalized_args.keys()),
            },
        )
        await self._pending.put(job_id)
        return job_id

    def get(self, job_id: str) -> JobStatus | None:
        return self._jobs.get(job_id)

    def list_jobs(self, limit: int = 100) -> list[dict]:
        """Return the most recent `limit` jobs, newest first."""
        jobs = sorted(self._jobs.values(), key=lambda j: j.created_at, reverse=True)
        return [j.to_dict() for j in jobs[:limit]]

    async def _start_workers(self) -> None:
        self._started = True
        for _ in range(self._max_workers):
            asyncio.create_task(self._worker())

    async def _worker(self) -> None:
        while True:
            job_id = await self._pending.get()
            status = self._jobs.get(job_id)
            if status is None:
                self._pending.task_done()
                continue

            args = getattr(status, "_args", {})
            handler = self._tool_registry.get(status.tool)

            status.state = State.RUNNING
            status.started_at = _now()
            status.result = None  # clear the temp args
            await record_job_progress(
                job_id=status.job_id,
                workflow_thread_id=status.workflow_thread_id or status.job_id,
                tool=status.tool,
                state=State.RUNNING.value,
                stage="dispatch",
                message=f"Dispatching {status.tool} handler",
                details={},
                started_at=datetime.now(timezone.utc),
            )

            if handler is None:
                status.state = State.FAILED
                status.error = f"No handler registered for tool '{status.tool}'"
                status.finished_at = _now()
                await record_job_progress(
                    job_id=status.job_id,
                    workflow_thread_id=status.workflow_thread_id or status.job_id,
                    tool=status.tool,
                    state=State.FAILED.value,
                    stage="dispatch_failed",
                    message=status.error,
                    details={},
                    error=status.error,
                    finished_at=datetime.now(timezone.utc),
                )
                self._pending.task_done()
                continue

            # Hard cap per-job: prevents orphaned jobs from monopolising the
            # worker and starving subsequent renders. The default budget is
            # intentionally longer for website-to-video and reference-driven
            # jobs, which can spend several minutes across analysis, render,
            # QA, and upload before the result is ready to poll.
            _JOB_TIMEOUT = int(__import__("os").getenv("JOB_TIMEOUT_SECS", "1500"))
            try:
                handler_args = self._filter_handler_args(handler, args)
                result = await asyncio.wait_for(handler(**handler_args), timeout=_JOB_TIMEOUT)
                status.state = State.COMPLETED
                status.result = result
                await record_job_progress(
                    job_id=status.job_id,
                    workflow_thread_id=status.workflow_thread_id or status.job_id,
                    tool=status.tool,
                    state=State.COMPLETED.value,
                    stage="completed",
                    message=f"{status.tool} job completed",
                    details={},
                    result=result,
                    finished_at=datetime.now(timezone.utc),
                )
            except asyncio.TimeoutError:
                status.state = State.FAILED
                status.error = f"Job exceeded maximum runtime of {_JOB_TIMEOUT}s"
                await record_job_progress(
                    job_id=status.job_id,
                    workflow_thread_id=status.workflow_thread_id or status.job_id,
                    tool=status.tool,
                    state=State.FAILED.value,
                    stage="timeout",
                    message=status.error,
                    details={"timeout_seconds": _JOB_TIMEOUT},
                    error=status.error,
                    finished_at=datetime.now(timezone.utc),
                )
            except Exception as exc:
                status.state = State.FAILED
                status.error = str(exc)
                await record_job_progress(
                    job_id=status.job_id,
                    workflow_thread_id=status.workflow_thread_id or status.job_id,
                    tool=status.tool,
                    state=State.FAILED.value,
                    stage="failed",
                    message=str(exc),
                    details={"exception_type": type(exc).__name__},
                    error=status.error,
                    finished_at=datetime.now(timezone.utc),
                )
            finally:
                status.finished_at = _now()
                self._pending.task_done()


# ---------------------------------------------------------------------------
# Singleton — default 1 worker: Render Standard has 1 vCPU, concurrent
# Blender subprocesses thrash CPU and both time out.  Override via env var.
# ---------------------------------------------------------------------------

queue = JobQueue(max_workers=int(__import__("os").getenv("JOB_QUEUE_WORKERS", "1")))
